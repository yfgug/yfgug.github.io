/* ============================================================
   旅行与生活 · site experience layer (Alpine v3)
   ------------------------------------------------------------
   - ridge reading progress with a moving waypoint marker
   - home hero: parallax scene, polaroids, trailhead links
   - time-of-day ambience (dawn / day / dusk / night stars)
   - category hues for home cards (trail / code / gear / life)
   - Ctrl+K (or /) opens the local search
   - random-post compass in the nav
   - local profile (avatar + name, stored in this browser)
   - reveal-on-scroll, soft pjax transitions, stale-link rescue
   ============================================================ */
(function () {
  'use strict'

  var PROFILE_KEY = 'travel_blog_profile_v1'
  var DEFAULT_PROFILE = {
    name: 'YFGUG',
    avatar: '/img/avatar.jpg'
  }
  var STALE_ARTICLE_ROUTES = {
    '/2026/06/13/thu-bdc2026-experiment-log/': 'content-20260613'
  }
  var CATEGORY_BUCKETS = [
    { bucket: 'gear', match: ['装备'] },
    { bucket: 'trail', match: ['徒步', '路线', '攻略', '户外'] },
    { bucket: 'code', match: ['项目', '比赛', '复盘', '日志', '技术'] },
    { bucket: 'life', match: ['随笔', '随想', '生活', '思考'] }
  ]
  var revealObserver = null
  var progressBound = false
  var profileKeyBound = false
  var profileClickBound = false
  var exploreBound = false
  var ambienceBound = false
  var softNavigationBound = false
  var searchKeyBound = false
  var postIndexPromise = null
  var exploreRaf = 0
  var explorePointer = { x: 0, y: 0 }

  function ready (fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn, { once: true })
    } else {
      fn()
    }
  }

  function safeGet (key) {
    try { return localStorage.getItem(key) } catch (err) { return null }
  }

  function safeSet (key, value) {
    try {
      localStorage.setItem(key, value)
      return true
    } catch (err) {
      return false
    }
  }

  function safeRemove (key) {
    try { localStorage.removeItem(key) } catch (err) {}
  }

  function normalizePath (path) {
    path = path.replace(/\/index\.html$/, '/')
    return path.endsWith('/') ? path : path + '/'
  }

  function withArticleVersion (path, version) {
    return path + '?v=' + encodeURIComponent(version)
  }

  function initStaleArticleRescue () {
    var path = normalizePath(window.location.pathname)
    var version = STALE_ARTICLE_ROUTES[path]

    if (version && !window.location.search) {
      var looksLikeCached404 = document.querySelector('.type-404, .error_title') || /^404\b/.test(document.title)
      if (looksLikeCached404) {
        window.location.replace(withArticleVersion(path, version))
        return
      }
    }

    Object.keys(STALE_ARTICLE_ROUTES).forEach(function (route) {
      var routeVersion = STALE_ARTICLE_ROUTES[route]
      var versionedHref = withArticleVersion(route, routeVersion)
      document.querySelectorAll('a[href="' + route + '"], a[href="' + window.location.origin + route + '"]').forEach(function (link) {
        link.setAttribute('href', versionedHref)
      })
    })
  }

  function scrollPercent () {
    var doc = document.documentElement
    var max = Math.max(doc.scrollHeight - window.innerHeight, 1)
    return Math.min(100, Math.max(0, Math.round((window.scrollY / max) * 100)))
  }

  function removeLegacyWidgets () {
    document.querySelectorAll('.cookie-consent, .home-dock').forEach(function (item) { item.remove() })
  }

  /* ---------- category hues for home cards ---------- */
  function categoryBucket (text) {
    text = String(text || '')
    if (!text) return ''
    for (var i = 0; i < CATEGORY_BUCKETS.length; i++) {
      var entry = CATEGORY_BUCKETS[i]
      for (var j = 0; j < entry.match.length; j++) {
        if (text.indexOf(entry.match[j]) !== -1) return entry.bucket
      }
    }
    return 'trail'
  }

  function initCategoryAccents () {
    document.querySelectorAll('#recent-posts .recent-post-item').forEach(function (card) {
      var category = card.querySelector('.article-meta__categories')
      var bucket = categoryBucket(category && category.textContent)
      if (bucket) card.setAttribute('data-cat', bucket)
    })
  }

  /* ---------- Ctrl+K / '/' opens the local search ---------- */
  function isTypingContext (target) {
    if (!target) return false
    if (target.isContentEditable) return true
    var tag = (target.tagName || '').toLowerCase()
    return tag === 'input' || tag === 'textarea' || tag === 'select'
  }

  function openSearchDialog () {
    var trigger = document.querySelector('#search-button .search')
    if (trigger) trigger.click()
  }

  function initSearchHotkey () {
    var searchPage = document.querySelector('#search-button .site-page')
    if (searchPage && !searchPage.querySelector('.search-kbd')) {
      var kbd = document.createElement('span')
      kbd.className = 'search-kbd'
      kbd.setAttribute('aria-hidden', 'true')
      kbd.textContent = 'Ctrl K'
      searchPage.appendChild(kbd)
    }

    if (searchKeyBound) return
    searchKeyBound = true

    document.addEventListener('keydown', function (event) {
      var searchOpen = document.querySelector('#local-search.is-show, .search-dialog[style*="display: block"]')

      if ((event.ctrlKey || event.metaKey) && String(event.key).toLowerCase() === 'k') {
        event.preventDefault()
        if (!searchOpen) openSearchDialog()
        return
      }

      if (event.key === '/' && !event.ctrlKey && !event.metaKey && !event.altKey) {
        if (isTypingContext(event.target) || searchOpen) return
        event.preventDefault()
        openSearchDialog()
      }
    })
  }

  /* ---------- local profile ---------- */
  function cleanProfileName (value) {
    var name = String(value || '').replace(/\s+/g, ' ').trim()
    return name ? name.slice(0, 28) : DEFAULT_PROFILE.name
  }

  function cleanAvatarValue (value) {
    var avatar = String(value || '').trim()
    if (!avatar) return DEFAULT_PROFILE.avatar
    if (/^data:image\/(png|jpe?g|webp|gif);base64,/i.test(avatar)) return avatar
    if (/^https?:\/\//i.test(avatar)) return avatar
    if (avatar.charAt(0) === '/') return avatar
    return DEFAULT_PROFILE.avatar
  }

  function normalizeProfile (profile) {
    profile = profile || {}
    return {
      name: cleanProfileName(profile.name),
      avatar: cleanAvatarValue(profile.avatar)
    }
  }

  function loadProfile () {
    var raw = safeGet(PROFILE_KEY)
    if (!raw) return normalizeProfile(DEFAULT_PROFILE)

    try {
      return normalizeProfile(JSON.parse(raw))
    } catch (err) {
      return normalizeProfile(DEFAULT_PROFILE)
    }
  }

  function storeProfile (profile) {
    return safeSet(PROFILE_KEY, JSON.stringify(normalizeProfile(profile)))
  }

  function notifyProfile (message) {
    if (window.Snackbar && typeof window.Snackbar.show === 'function') {
      window.Snackbar.show({
        text: message,
        pos: 'top-center',
        showAction: false,
        duration: 1800
      })
    }
  }

  function syncProfileModal (profile) {
    var modal = document.querySelector('.profile-modal')
    if (!modal) return

    profile = normalizeProfile(profile || loadProfile())

    var nameInput = modal.querySelector('[data-profile-name]')
    var avatarInput = modal.querySelector('[data-profile-avatar]')
    var preview = modal.querySelector('[data-profile-preview]')
    var currentName = modal.querySelector('[data-profile-current-name]')

    if (nameInput) nameInput.value = profile.name
    if (avatarInput) avatarInput.value = profile.avatar
    if (preview) preview.src = profile.avatar
    if (currentName) currentName.textContent = profile.name
  }

  function applyProfile (profile) {
    profile = normalizeProfile(profile || loadProfile())

    document.querySelectorAll('.author-info-name, .author-info__name').forEach(function (item) {
      item.textContent = profile.name
    })

    // In the file:// preview build, root-absolute avatar paths cannot resolve —
    // only rewrite images there when the visitor saved a custom avatar.
    if (window.location.protocol === 'file:' && profile.avatar === DEFAULT_PROFILE.avatar) {
      syncProfileModal(profile)
      return
    }

    document.querySelectorAll('#sidebar-menus .avatar-img img, .card-widget.card-info .avatar-img img, img[alt="avatar"]').forEach(function (image) {
      if (!image.dataset.defaultProfileAvatar) {
        image.dataset.defaultProfileAvatar = image.getAttribute('src') || DEFAULT_PROFILE.avatar
      }
      if (image.getAttribute('src') !== profile.avatar) {
        image.setAttribute('src', profile.avatar)
      }
      image.onerror = function () {
        this.onerror = null
        this.setAttribute('src', DEFAULT_PROFILE.avatar)
      }
    })

    syncProfileModal(profile)
  }

  function closeProfileModal () {
    var modal = document.querySelector('.profile-modal')
    if (!modal) return

    modal.classList.remove('is-visible')
    modal.setAttribute('aria-hidden', 'true')
    document.documentElement.classList.remove('profile-modal-open')
  }

  function openProfileModal () {
    var modal = ensureProfileModal()
    syncProfileModal(loadProfile())
    modal.classList.add('is-visible')
    modal.setAttribute('aria-hidden', 'false')
    document.documentElement.classList.add('profile-modal-open')

    var nameInput = modal.querySelector('[data-profile-name]')
    if (nameInput) {
      setTimeout(function () { nameInput.focus() }, 80)
    }
  }

  function resizeAvatarDataUrl (dataUrl, callback) {
    var image = new Image()

    image.onload = function () {
      try {
        var canvas = document.createElement('canvas')
        var size = 512
        var side = Math.min(image.naturalWidth || image.width, image.naturalHeight || image.height)
        var sourceX = ((image.naturalWidth || image.width) - side) / 2
        var sourceY = ((image.naturalHeight || image.height) - side) / 2
        var context = canvas.getContext('2d')

        canvas.width = size
        canvas.height = size
        context.imageSmoothingQuality = 'high'
        context.drawImage(image, sourceX, sourceY, side, side, 0, 0, size, size)

        var output = canvas.toDataURL('image/webp', 0.86)
        if (!output || output.length > 1800000) {
          output = canvas.toDataURL('image/jpeg', 0.82)
        }
        callback(output || dataUrl)
      } catch (err) {
        callback(dataUrl)
      }
    }

    image.onerror = function () { callback(dataUrl) }
    image.src = dataUrl
  }

  function readAvatarFile (file, callback) {
    if (!file || !/^image\//i.test(file.type || '')) {
      notifyProfile('请选择图片文件')
      return
    }

    var reader = new FileReader()
    reader.onload = function () {
      resizeAvatarDataUrl(String(reader.result || ''), callback)
    }
    reader.onerror = function () {
      notifyProfile('图片读取失败')
    }
    reader.readAsDataURL(file)
  }

  function ensureProfileModal () {
    var modal = document.querySelector('.profile-modal')
    if (modal) return modal

    modal = document.createElement('div')
    modal.className = 'profile-modal'
    modal.setAttribute('aria-hidden', 'true')
    modal.innerHTML = [
      '<div class="profile-modal__backdrop" data-profile-close></div>',
      '<section class="profile-modal__panel" role="dialog" aria-modal="true" aria-label="Profile settings">',
      '  <div class="profile-modal__shine"></div>',
      '  <button class="profile-modal__close" type="button" data-profile-close aria-label="Close"><i class="fas fa-xmark"></i></button>',
      '  <div class="profile-modal__header">',
      '    <img class="profile-modal__avatar" data-profile-preview src="' + DEFAULT_PROFILE.avatar + '" alt="avatar preview">',
      '    <div class="profile-modal__title">',
      '      <div class="profile-modal__eyebrow">LOCAL PROFILE</div>',
      '      <h2>&#20010;&#24615;&#36164;&#26009;</h2>',
      '      <p>&#22836;&#20687;&#21644;&#29992;&#25143;&#21517;&#20250;&#20445;&#23384;&#22312;&#24403;&#21069;&#27983;&#35272;&#22120;&#12290;</p>',
      '    </div>',
      '  </div>',
      '  <div class="profile-modal__body">',
      '    <label class="profile-modal__field">',
      '      <span>&#29992;&#25143;&#21517;&#31216;</span>',
      '      <input type="text" maxlength="28" autocomplete="off" data-profile-name placeholder="YFGUG">',
      '    </label>',
      '    <label class="profile-modal__field">',
      '      <span>&#22836;&#20687;&#38142;&#25509;</span>',
      '      <input type="url" data-profile-avatar placeholder="/img/avatar.jpg">',
      '    </label>',
      '    <label class="profile-modal__file">',
      '      <input type="file" accept="image/png,image/jpeg,image/webp,image/gif" data-profile-file>',
      '      <i class="fas fa-image"></i>',
      '      <span>&#36873;&#25321;&#26412;&#22320;&#22836;&#20687;</span>',
      '    </label>',
      '    <div class="profile-modal__hint">&#26412;&#22320;&#22270;&#29255;&#20250;&#33258;&#21160;&#35009;&#20999;&#24182;&#21387;&#32553;&#65292;&#19981;&#20250;&#19978;&#20256;&#21040;&#26381;&#21153;&#22120;&#12290;</div>',
      '  </div>',
      '  <div class="profile-modal__actions">',
      '    <button type="button" class="profile-modal__button profile-modal__button--ghost" data-profile-action="reset">&#24674;&#22797;&#40664;&#35748;</button>',
      '    <button type="button" class="profile-modal__button" data-profile-close>&#21462;&#28040;</button>',
      '    <button type="button" class="profile-modal__button profile-modal__button--primary" data-profile-action="save">&#20445;&#23384;</button>',
      '  </div>',
      '</section>'
    ].join('')

    modal.addEventListener('click', function (event) {
      if (event.target.closest('[data-profile-close]')) {
        closeProfileModal()
        return
      }

      var action = event.target.closest('[data-profile-action]')
      if (!action) return

      if (action.getAttribute('data-profile-action') === 'reset') {
        safeRemove(PROFILE_KEY)
        applyProfile(DEFAULT_PROFILE)
        syncProfileModal(DEFAULT_PROFILE)
        notifyProfile('已恢复默认资料')
        return
      }

      if (action.getAttribute('data-profile-action') === 'save') {
        var nextProfile = normalizeProfile({
          name: modal.querySelector('[data-profile-name]').value,
          avatar: modal.querySelector('[data-profile-avatar]').value
        })

        if (storeProfile(nextProfile)) {
          applyProfile(nextProfile)
          closeProfileModal()
          notifyProfile('个性资料已保存')
        } else {
          notifyProfile('保存失败，可能是图片太大了')
        }
      }
    })

    modal.querySelector('[data-profile-avatar]').addEventListener('input', function () {
      var preview = modal.querySelector('[data-profile-preview]')
      if (preview) preview.src = cleanAvatarValue(this.value)
    })

    modal.querySelector('[data-profile-name]').addEventListener('input', function () {
      var currentName = modal.querySelector('[data-profile-current-name]')
      if (currentName) currentName.textContent = cleanProfileName(this.value)
    })

    modal.querySelector('[data-profile-file]').addEventListener('change', function () {
      var file = this.files && this.files[0]
      readAvatarFile(file, function (avatar) {
        var avatarInput = modal.querySelector('[data-profile-avatar]')
        var preview = modal.querySelector('[data-profile-preview]')
        if (avatarInput) avatarInput.value = avatar
        if (preview) preview.src = avatar
        notifyProfile('头像已读取，点击保存生效')
      })
    })

    if (!profileKeyBound) {
      profileKeyBound = true
      document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') closeProfileModal()
      })
    }

    document.body.appendChild(modal)
    return modal
  }

  function createProfileButton (className, withText) {
    var button = document.createElement('button')
    button.type = 'button'
    button.className = className
    button.setAttribute('title', '修改头像和用户名')
    button.setAttribute('aria-label', '修改头像和用户名')
    button.innerHTML = '<i class="fas fa-user-pen"></i>' + (withText ? '<span>&#20010;&#24615;&#35774;&#32622;</span>' : '')
    button.addEventListener('click', openProfileModal)
    return button
  }

  function initProfileControls () {
    applyProfile()

    if (!profileClickBound) {
      profileClickBound = true
      document.addEventListener('click', function (event) {
        var button = event.target.closest('.profile-settings-card-btn, .profile-floating-btn')
        if (!button) return
        event.preventDefault()
        event.stopPropagation()
        openProfileModal()
      }, true)
    }

    document.querySelectorAll('.card-widget.card-info').forEach(function (card) {
      if (card.querySelector('.profile-settings-card-btn')) return

      var anchor = card.querySelector('.author-info-description') || card.querySelector('.author-info__description') || card.querySelector('.author-info-name') || card.querySelector('.author-info__name')
      var button = createProfileButton('profile-settings-card-btn', true)
      if (anchor && anchor.parentNode) {
        anchor.insertAdjacentElement('afterend', button)
      } else {
        card.insertBefore(button, card.firstChild)
      }
    })

    if (!document.querySelector('.profile-floating-btn')) {
      document.body.appendChild(createProfileButton('profile-floating-btn', false))
    }

    ensureProfileModal()
  }

  /* ---------- ridge reading progress ---------- */
  function initProgress () {
    var progress = document.querySelector('.trail-progress')
    if (!progress) {
      progress = document.createElement('div')
      progress.className = 'trail-progress'
      progress.setAttribute('role', 'progressbar')
      progress.setAttribute('aria-label', '阅读进度')
      progress.setAttribute('aria-valuemin', '0')
      progress.setAttribute('aria-valuemax', '100')
      progress.innerHTML = [
        '<div class="trail-progress__track" aria-hidden="true">',
        '  <svg class="trail-progress__ridge" viewBox="0 0 100 28" preserveAspectRatio="none">',
        '    <polyline class="trail-progress__ridge-base" points="0,24 9,19 18,22 28,12 38,17 48,8 58,15 69,5 78,13 88,7 100,2"></polyline>',
        '    <polyline class="trail-progress__ridge-fill" points="0,24 9,19 18,22 28,12 38,17 48,8 58,15 69,5 78,13 88,7 100,2"></polyline>',
        '  </svg>',
        '  <span class="trail-progress__marker"></span>',
        '</div>'
      ].join('')
      document.body.appendChild(progress)
    }

    function markerY (percent) {
      var points = [[0, 24], [9, 19], [18, 22], [28, 12], [38, 17], [48, 8], [58, 15], [69, 5], [78, 13], [88, 7], [100, 2]]

      for (var index = 1; index < points.length; index++) {
        if (percent > points[index][0]) continue
        var start = points[index - 1]
        var end = points[index]
        var ratio = (percent - start[0]) / Math.max(end[0] - start[0], 1)
        return start[1] + ((end[1] - start[1]) * ratio)
      }

      return points[points.length - 1][1]
    }

    function update () {
      var percent = scrollPercent()
      progress.style.setProperty('--trail-progress', percent + '%')
      progress.style.setProperty('--trail-marker-y', markerY(percent) + 'px')
      progress.setAttribute('aria-valuenow', String(percent))
      progress.classList.toggle('is-active', percent > 1)
      progress.classList.toggle('is-complete', percent >= 99)
    }

    update()
    if (!progressBound) {
      progressBound = true
      window.addEventListener('scroll', update, { passive: true })
      window.addEventListener('resize', update)
    }
  }

  /* ---------- reveal on scroll ---------- */
  function initReveal () {
    var targets = document.querySelectorAll('#recent-posts .recent-post-item, .card-widget, .article-sort-item')
    if (revealObserver) revealObserver.disconnect()

    if (!('IntersectionObserver' in window)) {
      targets.forEach(function (item) { item.classList.add('is-visible') })
      return
    }

    revealObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return
        entry.target.classList.add('is-visible')
        revealObserver.unobserve(entry.target)
      })
    }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' })

    targets.forEach(function (item, index) {
      item.style.setProperty('--reveal-delay', Math.min(index * 45, 360) + 'ms')
      revealObserver.observe(item)
    })
  }

  /* ---------- home hero ---------- */
  function isHomePage () {
    var path = window.location.pathname.replace(/\/index\.html$/, '/')
    return path === '/' || path === ''
  }

  function removeExploreHero () {
    document.documentElement.classList.remove('explore-home')
    document.querySelectorAll('.explore-hero-scene, .explore-hero-links, .hero-ambience').forEach(function (item) {
      item.remove()
    })
  }

  function currentHeroPeriod () {
    var hour = new Date().getHours()
    if (hour >= 5 && hour < 8) return 'dawn'
    if (hour >= 8 && hour < 17) return 'day'
    if (hour >= 17 && hour < 20) return 'dusk'
    return 'night'
  }

  function applyHeroPeriod () {
    var periods = ['dawn', 'day', 'dusk', 'night']
    periods.forEach(function (period) {
      document.documentElement.classList.remove('hero-time-' + period)
    })

    if (!isHomePage()) return
    document.documentElement.classList.add('hero-time-' + currentHeroPeriod())
  }

  function initHeroAmbience () {
    applyHeroPeriod()

    if (!isHomePage()) {
      var oldAmbience = document.querySelector('.hero-ambience')
      if (oldAmbience) oldAmbience.remove()
      return
    }

    var header = document.querySelector('#page-header.full_page')
    if (!header) return

    if (!header.querySelector('.hero-ambience')) {
      var ambience = document.createElement('div')
      ambience.className = 'hero-ambience'
      ambience.setAttribute('aria-hidden', 'true')
      ambience.innerHTML = [
        '<span class="hero-ambience__mist"></span>',
        '<span class="hero-ambience__stars"></span>',
        '<span class="hero-ambience__meteor"></span>'
      ].join('')
      header.appendChild(ambience)
    }

    if (!ambienceBound) {
      ambienceBound = true
      window.setInterval(applyHeroPeriod, 60000)
    }
  }

  function scheduleExploreMotion () {
    if (exploreRaf) return

    exploreRaf = window.requestAnimationFrame(function () {
      exploreRaf = 0
      updateExploreMotion()
    })
  }

  function updateExploreMotion () {
    if (!document.documentElement.classList.contains('explore-home')) return

    var header = document.querySelector('#page-header.full_page')
    if (!header) return

    var rect = header.getBoundingClientRect()
    var height = Math.max(rect.height, 1)
    var progress = Math.min(1, Math.max(0, -rect.top / height))

    document.documentElement.style.setProperty('--explore-scroll', progress.toFixed(3))
    document.documentElement.style.setProperty('--explore-x', explorePointer.x.toFixed(3))
    document.documentElement.style.setProperty('--explore-y', explorePointer.y.toFixed(3))
  }

  function bindExploreMotion () {
    if (exploreBound) return

    exploreBound = true

    window.addEventListener('pointermove', function (event) {
      if (!document.documentElement.classList.contains('explore-home')) return
      if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return

      explorePointer.x = (event.clientX / Math.max(window.innerWidth, 1)) - 0.5
      explorePointer.y = (event.clientY / Math.max(window.innerHeight, 1)) - 0.5
      scheduleExploreMotion()
    }, { passive: true })

    window.addEventListener('scroll', scheduleExploreMotion, { passive: true })
    window.addEventListener('resize', scheduleExploreMotion)
  }

  function createExploreHeroScene () {
    var scene = document.createElement('div')
    scene.className = 'explore-hero-scene'
    scene.setAttribute('aria-hidden', 'true')
    scene.innerHTML = [
      '<div class="explore-hero-layer explore-hero-layer--back"></div>',
      '<div class="explore-hero-layer explore-hero-layer--mist"></div>',
      '<div class="explore-hero-photos">',
      '  <span class="explore-hero-photo explore-hero-photo--one"></span>',
      '  <span class="explore-hero-photo explore-hero-photo--two"></span>',
      '  <span class="explore-hero-photo explore-hero-photo--three"></span>',
      '</div>'
    ].join('')

    return scene
  }

  function createExploreHeroRidge () {
    var ridge = document.createElement('div')
    ridge.className = 'explore-hero-ridge'
    ridge.setAttribute('aria-hidden', 'true')
    return ridge
  }

  function createExploreHeroLinks () {
    var links = document.createElement('div')
    links.className = 'explore-hero-links'
    links.innerHTML = [
      '<a class="explore-hero-link" href="/categories/%E5%BE%92%E6%AD%A5%E6%B8%B8%E8%AE%B0/">',
      '  <i class="fas fa-route"></i><span><b>&#24466;&#27493;&#28216;&#35760;</b><small>Trail Notes</small></span>',
      '</a>',
      '<a class="explore-hero-link" href="/categories/%E9%A1%B9%E7%9B%AE/">',
      '  <i class="fas fa-terminal"></i><span><b>&#39033;&#30446;&#26723;&#26696;</b><small>Build Logs</small></span>',
      '</a>',
      '<a class="explore-hero-link" href="/categories/%E6%AF%94%E8%B5%9B%E5%A4%8D%E7%9B%98/">',
      '  <i class="fas fa-chart-simple"></i><span><b>&#27604;&#36187;&#22797;&#30424;</b><small>Review</small></span>',
      '</a>'
    ].join('')

    return links
  }

  function initExploreHero () {
    if (!isHomePage()) {
      removeExploreHero()
      return
    }

    var header = document.querySelector('#page-header.full_page')
    if (!header) return

    document.documentElement.classList.add('explore-home')

    if (!header.querySelector('.explore-hero-scene')) {
      header.insertBefore(createExploreHeroScene(), header.firstChild)
    }

    if (!header.querySelector('.explore-hero-ridge')) {
      header.appendChild(createExploreHeroRidge())
    }

    if (!header.querySelector('.explore-hero-links')) {
      var siteInfo = header.querySelector('#site-info')
      var links = createExploreHeroLinks()
      if (siteInfo && siteInfo.parentNode) {
        siteInfo.insertAdjacentElement('afterend', links)
      } else {
        header.appendChild(links)
      }
    }

    bindExploreMotion()
    scheduleExploreMotion()
  }

  /* ---------- random post compass ---------- */
  function loadPostIndex () {
    if (postIndexPromise) return postIndexPromise

    postIndexPromise = window.fetch('/search.xml', { cache: 'force-cache' })
      .then(function (response) {
        if (!response.ok) throw new Error('Search index unavailable')
        return response.text()
      })
      .then(function (text) {
        var xml = new window.DOMParser().parseFromString(text, 'application/xml')
        return Array.from(xml.querySelectorAll('entry url'))
          .map(function (item) { return item.textContent.trim() })
          .filter(function (url) { return /^\/\d{4}\/\d{2}\/\d{2}\//.test(url) })
      })
      .catch(function (error) {
        postIndexPromise = null
        throw error
      })

    return postIndexPromise
  }

  function initRandomPost () {
    var nav = document.querySelector('#nav')
    var searchButton = document.querySelector('#search-button')
    if (!nav || !searchButton || document.querySelector('.random-post-nav')) return

    var button = document.createElement('button')
    button.type = 'button'
    button.className = 'random-post-nav'
    button.setAttribute('title', '随机出发')
    button.setAttribute('aria-label', '随机出发')
    button.innerHTML = '<i class="fas fa-compass"></i>'

    button.addEventListener('click', function () {
      if (button.disabled) return
      button.disabled = true
      button.classList.add('is-spinning')

      loadPostIndex()
        .then(function (posts) {
          var current = normalizePath(window.location.pathname)
          var candidates = posts.filter(function (url) { return normalizePath(url) !== current })
          if (!candidates.length) throw new Error('No random post available')

          var target = candidates[Math.floor(Math.random() * candidates.length)]
          window.setTimeout(function () { window.location.assign(target) }, 620)
        })
        .catch(function () {
          button.disabled = false
          button.classList.remove('is-spinning')
        })
    })

    searchButton.parentNode.insertBefore(button, searchButton)
  }

  /* ---------- soft pjax transitions ---------- */
  function initSoftNavigation () {
    if (softNavigationBound) return
    softNavigationBound = true

    document.addEventListener('pjax:send', function () {
      document.documentElement.classList.remove('soft-nav-entering')
      document.documentElement.classList.add('soft-nav-leaving')
    })

    document.addEventListener('pjax:complete', function () {
      document.documentElement.classList.remove('soft-nav-leaving')
      document.documentElement.classList.add('soft-nav-entering')
      window.setTimeout(function () {
        document.documentElement.classList.remove('soft-nav-entering')
      }, 340)
    })
  }

  /* ---------- boot ---------- */
  function initSiteExperience () {
    document.documentElement.classList.add('blog-js-ready')
    removeLegacyWidgets()
    initSoftNavigation()
    initStaleArticleRescue()
    initProgress()
    initExploreHero()
    initHeroAmbience()
    initCategoryAccents()
    initSearchHotkey()
    initRandomPost()
    initProfileControls()
    initReveal()
  }

  ready(initSiteExperience)
  document.addEventListener('pjax:complete', initSiteExperience)
})()
